package school.devskill.testSpring.Controllers;

import org.springframework.web.bind.annotation.*;
import school.devskill.testSpring.Utility.HTTPUtility;

@RestController
@RequestMapping("comic")
public class Fumetto {

    private Object HTTPUtilty;

    @PostMapping(value = HTTPUtility.CREATE)
    public void comicCreate(){}

    @DeleteMapping(value = HTTPUtility.DELETE)
    public void comicDelete(){}

    @PutMapping(value = HTTPUtility.UPDATE)
    public void comicUpdate(){}
}
