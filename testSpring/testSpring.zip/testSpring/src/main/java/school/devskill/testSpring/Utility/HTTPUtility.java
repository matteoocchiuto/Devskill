package school.devskill.testSpring.Utility;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class HTTPUtility {

    public static final String UPDATE = "/update";
    public static final String DELETE = "/delete";
    public static final String CREATE = "/create";

    }

