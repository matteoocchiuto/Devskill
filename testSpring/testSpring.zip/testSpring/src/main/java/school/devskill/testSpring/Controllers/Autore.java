package school.devskill.testSpring.Controllers;

import org.springframework.web.bind.annotation.*;
import school.devskill.testSpring.Utility.HTTPUtility;

@RestController
@RequestMapping("author")

public class Autore {
        @PostMapping(value = HTTPUtility.CREATE)
        public void authorCreate(){}

        @DeleteMapping(value = HTTPUtility.DELETE)
        public void authorDelete(){}

        @PutMapping(value = HTTPUtility.UPDATE)
        public void authorUpdate(){}
}
